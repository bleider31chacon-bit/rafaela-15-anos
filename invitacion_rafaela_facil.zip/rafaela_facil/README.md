# Rafaela 15 años — versión fácil

Solo necesitas subir `server.js`, `package.json` y este README al repositorio de GitHub.

Render: Build Command `npm install`; Start Command `npm start`.

En Environment Variables crea `ADMIN_PASSWORD` con una clave privada.

Invitación: `/`
Panel privado: `/admin`
