const express = require('express');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'CAMBIAR_CLAVE';
const DATA_FILE = process.env.DATA_FILE || path.join(__dirname, 'rsvps.json');

app.use(express.json({limit:'20kb'}));

function readData(){
  try { return JSON.parse(fs.readFileSync(DATA_FILE,'utf8')); }
  catch { return []; }
}
function saveData(data){ fs.writeFileSync(DATA_FILE, JSON.stringify(data,null,2)); }
function esc(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));}

const page = `<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Rafaela Celeste | Mis 15 años</title><style>
*{box-sizing:border-box}body{margin:0;background:#061638;color:#fff;font-family:Arial,sans-serif}.stars{position:fixed;inset:0;pointer-events:none;background-image:radial-gradient(#fff 1px,transparent 1px),radial-gradient(#b9d5ff 1px,transparent 1px);background-size:73px 73px,121px 121px;opacity:.3}main{max-width:720px;margin:auto;position:relative}.hero{text-align:center;min-height:680px;padding:70px 20px;display:flex;flex-direction:column;justify-content:center;align-items:center;background:radial-gradient(circle at 50% 30%,#2e63b5,#102b68 45%,#061438)}.castle{font-size:55px;color:#e8d69b}.eyebrow{letter-spacing:5px;color:#e8d69b;font-size:12px}.hero h1{font-family:Georgia,serif;font-size:45px;line-height:1;margin:10px 0}.hero h1 span{font-size:32px}.crown{font-size:40px;color:#f3d58a}.fifteen{font:34px Georgia,serif;color:#e9d49b}.intro{line-height:1.8;color:#dce7ff;font-size:14px}.card{margin:25px 16px;padding:34px 22px;background:#102d69ee;border:1px solid #d9bd70aa;border-radius:22px;text-align:center;box-shadow:0 15px 50px #0005}.card h2{font:34px Georgia,serif;color:#f1d999}.details{display:grid;gap:20px;margin-top:25px}.details b{display:block;font:26px Georgia,serif}.details span{display:block;font-size:10px;letter-spacing:2px;color:#b9ccef;margin-top:4px}.count{text-align:center;padding:25px 12px}.timer{display:flex;justify-content:center;gap:7px}.timer div{min-width:68px;padding:13px 5px;border:1px solid #d9bd7066;border-radius:10px;background:#0b2353}.timer b{display:block;font:32px Georgia,serif;color:#f5dc9a}.timer span{font-size:8px;color:#b9ccef}label{display:block;text-align:left;font-size:11px;letter-spacing:1px;margin:14px 0}input{width:100%;margin-top:7px;padding:14px;border-radius:11px;border:1px solid #cdb56e77;background:#06183c;color:#fff;font-size:16px}button{width:100%;padding:15px;border:0;border-radius:11px;background:linear-gradient(90deg,#c9a94e,#f0d48c,#c9a94e);color:#142650;font-weight:bold;letter-spacing:1px;margin-top:8px}.ok{color:#f3d994;line-height:1.8;margin-top:20px}footer{text-align:center;padding:35px;color:#d8c17d;font:22px Georgia,serif}@media(max-width:430px){.hero h1{font-size:36px}.hero h1 span{font-size:25px}.card h2{font-size:29px}}
</style></head><body><div class="stars"></div><main><section class="hero"><div class="castle">♜</div><p class="eyebrow">ÉRASE UNA VEZ...</p><h1>Rafaela Celeste<br><span>Conde Anampa</span></h1><div class="crown">♕</div><p class="fifteen">Mis 15 años</p><p class="intro">Una noche mágica está por comenzar.<br>Quiero compartirla contigo.</p></section><section class="card"><h2>Una noche de cuento de hadas</h2><div style="font-size:38px;color:#d9ebff">♢</div><div class="details"><div><b>24 de octubre de 2026</b><span>FECHA</span></div><div><b>8:30 p. m.</b><span>HORA</span></div><div><b>Recepción Andia</b><span>LUGAR</span></div></div></section><section class="count"><p style="letter-spacing:3px;font-size:10px;color:#e5ca88">FALTA PARA LA NOCHE MÁGICA</p><div class="timer"><div><b id="d">--</b><span>DÍAS</span></div><div><b id="h">--</b><span>HORAS</span></div><div><b id="m">--</b><span>MIN</span></div><div><b id="s">--</b><span>SEG</span></div></div></section><section class="card"><h2>¿Nos acompañas?</h2><p style="color:#d2ddf4;font-size:13px">Confirma tu asistencia para ser parte de esta noche inolvidable.</p><form id="f"><label>Nombre<input id="n" required maxlength="80" placeholder="Tu nombre"></label><label>Apellidos<input id="a" required maxlength="100" placeholder="Tus apellidos"></label><button>CONFIRMAR ASISTENCIA ✨</button></form><div id="ok" class="ok" hidden>✨ Tu asistencia ha sido confirmada.<br>Gracias por ser parte de esta noche mágica.</div></section><footer>Con cariño, Rafaela Celeste 💙</footer></main><script>
const t=new Date('2026-10-24T20:30:00-05:00').getTime();function q(){let x=t-Date.now();if(x<0)x=0;d.textContent=Math.floor(x/864e5);h.textContent=Math.floor(x%864e5/36e5);m.textContent=Math.floor(x%36e5/6e4);s.textContent=Math.floor(x%6e4/1e3)}q();setInterval(q,1000);
f.onsubmit=async e=>{e.preventDefault();let b=e.target.querySelector('button');b.disabled=true;try{let r=await fetch('/api/rsvp',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:n.value.trim(),lastname:a.value.trim()})});if(!r.ok)throw 0;f.hidden=true;ok.hidden=false}catch(_){alert('No se pudo registrar. Inténtalo nuevamente.');b.disabled=false}};
</script></body></html>`;

app.get('/',(_,res)=>res.type('html').send(page));
app.post('/api/rsvp',(req,res)=>{
  const name=String(req.body.name||'').trim(), lastname=String(req.body.lastname||'').trim();
  if(!name||!lastname)return res.status(400).json({error:'Datos inválidos'});
  const data=readData(); data.push({name,lastname,created_at:new Date().toISOString()}); saveData(data); res.json({ok:true});
});
app.get('/admin',(req,res)=>{
  if(req.query.key!==ADMIN_PASSWORD)return res.status(401).send('<h2>Acceso denegado</h2>');
  const rows=readData().reverse();
  res.type('html').send('<meta name="viewport" content="width=device-width"><style>body{font-family:Arial;background:#071a49;color:white;padding:20px}li{padding:10px 0;border-bottom:1px solid #ffffff33}</style><h1>Personas registradas: '+rows.length+'</h1><ol>'+rows.map(x=>'<li>'+esc(x.name)+' '+esc(x.lastname)+' — '+new Date(x.created_at).toLocaleString('es-PE')}</li>').join('')+'</ol>');
});
app.listen(PORT,()=>console.log('Servidor activo en puerto '+PORT));
